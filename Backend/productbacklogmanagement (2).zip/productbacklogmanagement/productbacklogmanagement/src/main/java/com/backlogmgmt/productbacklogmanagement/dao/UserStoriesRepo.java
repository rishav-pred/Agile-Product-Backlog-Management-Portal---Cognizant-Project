package com.backlogmgmt.productbacklogmanagement.dao;

public interface UserStoriesRepo {

}
